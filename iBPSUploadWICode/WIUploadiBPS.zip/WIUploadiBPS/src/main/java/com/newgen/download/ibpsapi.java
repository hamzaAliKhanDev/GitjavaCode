package com.newgen.download;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.jar.JarException;

import org.json.JSONObject;

import com.newgen.dmsapi.DMSCallBroker;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.NGException;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;


public class ibpsapi extends demo {
	
	String sessionId = "";
    String volumeid ="";


	    public static NGEjbClient ngEJBClient;
	   
	    public ibpsapi() throws Exception {
	        /*engineName = "hamzacab";
	        dmsUserName = "padmin";
	        dmsUserPswd = "system123#";
	        serverIP = "192.168.149.192";
	        serverPort = "8080";
	        serverType = "jbosseap";
	        jtsPort = "3333";*/
	    }

	    public String connectFlow() {
	        String outputXml = null;
	        DMSXmlResponse xmlResponse = null;
	        
	        
	        String inputXml = "<? xml version=\"1.0\"?>"
	                + "<NGOConnectCabinet_Input>"
	                + "<Option>NGOConnectCabinet</Option><CabinetName>"
	                + engineName + "</CabinetName><UserName>"
	                + dmsUserName + "</UserName><UserPassword>"
	                + dmsUserPswd + "</UserPassword>"
	                + "<Scope>ADMIN</Scope>"
	                + "<UserExist>N</UserExist><CurrentDateTime></CurrentDateTime><UserType>U</UserType>"
	                + "<MainGroupIndex>0</MainGroupIndex><Locale></Locale></NGOConnectCabinet_Input>";
	        		System.out.println(inputXml);
	        		//outputXml = DMSCallBroker.execute(inputXml.toString(), "192.168.136.154", Integer.parseInt("3333"), "8859_1", 1, false);
	        try {	
	        		outputXml= executeWithCallBroker(inputXml);
	        		
	            xmlResponse = new DMSXmlResponse(outputXml);
	             // System.out.println(xmlResponse);
	            if (xmlResponse.getVal("Status").equalsIgnoreCase("0")) {
	                sessionId = xmlResponse.getVal("UserDBId");
	              // System.out.println(sessionId);
	                volumeid=xmlResponse.getVal("ImageVolumeIndex");
	                System.out.println(sessionId);
	                return sessionId+"_"+volumeid;
	            }else {
	                return null;
	            }}
	        catch (Exception e) {
	        	return null;
	        	} finally {
	        	if (xmlResponse != null) {
	        	xmlResponse = null;
	        	}
	        	}
	        	}
	        
	            public static String executeWithCallBroker(String inputXml) throws NGException, IOException {
	            	String outputXml = "";
	            	System.out.println("before callbroker");
	            	outputXml = DMSCallBroker.execute(inputXml, serverIP, Short.parseShort(jtsPort), "8859_1",1,false);
	            	System.out.println("after call broker");

	            	//System.out.println(outputXml);
	            	return outputXml;
	            	
	            }
	        public JSONObject uploadWI() {
	    	
	    	String processInstanceID = null;
	    	DMSXmlResponse xmlResponse = null;
	    	StringBuffer inputXml = new StringBuffer();
	    	String outputXml = null;
	    	String mainCode = null;
	    	String folderIndex = null;
	    	String documents = null;

	    	System.out.println("ApplicantName"+ApplicantName);
	    	//=======Upload Call===========//
	    	
	    	try {
	    		inputXml.append("<WFUploadWorkItem_Input>");
	    		inputXml.append("<Option>WFUploadWorkItem</Option>");
	    		inputXml.append("<EngineName>" + engineName + "</EngineName>");
	    		inputXml.append("<SessionId>" + sessionId + "</SessionId>");
	    		inputXml.append("<ProcessDefId>" + "1003" + "</ProcessDefId>");
	    		inputXml.append("<QueueId>" + "2008" + "</QueueId>");
	    		inputXml.append("<InitiateFromActivityId></InitiateFromActivityId>");
	    		inputXml.append("<InitiateAlso>Y</InitiateAlso>");
	    		inputXml.append("<VariantId>"+"0"+"</VariantId>");
	    		inputXml.append("<UserDefVarFlag>Y</UserDefVarFlag>");
	    		inputXml.append("<Documents></Documents>");
	    		//inputXml.append("<Attributes></Attributes>");
	    		inputXml.append("<Attributes><ApplicantName>"+ApplicantName+"</ApplicantName><DateBirth>"+DateBirth+"</DateBirth><FatherName>"+FatherName+"</FatherName><Address>"+Address+"</Address><AadharNumber>"+AadharNumber+"</AadharNumber><PanNumber>"+PanNumber+"</PanNumber><FormNumber>"+FormNumber+"</FormNumber><AppDate>"+AppDate+"</AppDate><AppliedAmount>"+AppliedAmount+"</AppliedAmount><GuaranteeName>"+GuaranteeName+"</GuaranteeName><BankName>"+BankName+"</BankName><BranchName>"+BranchName+"</BranchName><BankAccNumber>"+BankAccNumber+"</BankAccNumber><IFSCCode>"+IFSCCode+"</IFSCCode><Name>"+Name+"</Name><Place>"+Place+"</Place><SignDate>"+SignDate+"</SignDate></Attributes>");
	    		inputXml.append("</WFUploadWorkItem_Input>");

	    				System.out.println(inputXml);
	    				

	    	 
	    	
	    	 
	    	outputXml = ibpsapi.executeWithCallBroker(inputXml.toString());
	    	System.out.println("+++++++++upload workitem++++++++++++");
	    	System.out.println(outputXml);
	    	
	    	xmlResponse = new DMSXmlResponse(outputXml);
	    	mainCode = xmlResponse.getVal("MainCode");
	    	folderIndex = xmlResponse.getVal("FolderIndex");



	    	if (mainCode.equals("0")) {
	    	//processInstanceID = xmlResponse.getVal("ProcessInstanceId");
	    	json.put("Status","Workitem created Succesfully!");
	    	json.put("OutputXML",outputXml);
	    	
	    	
	    	} 
	    	else {
	    		
	    		json.put("Status","Failed!");
		    	json.put("OutputXML",outputXml);
		    	
	    	
	    	}
	    	} catch (Exception e) {
	    	
	    		e.printStackTrace();
	    	} finally {
	    	if (xmlResponse != null) {
	    	xmlResponse = null;
	    	}
	    	}
	    	return json;
	    	}
	  
	        public String DisconnectFlow() {
		        String outputXml1 = null;
		        DMSXmlResponse xmlResponse1 = null;
	        String inputXml1 = "<? xml version=\"1.0\"?>"
	                + "<NGODisconnectCabinet_Input>"
	                + "<Option>NGODisconnectCabinet</Option><CabinetName>"
	                + engineName + "</CabinetName><UserDBId>"
	                + sessionId + "</UserDBId></NGOConnectCabinet_Input>";
	        		System.out.println(inputXml1);
	        		//outputXml = DMSCallBroker.execute(inputXml.toString(), "192.168.136.154", Integer.parseInt("3333"), "8859_1", 1, false);
	        try {	
	        		outputXml1= executeWithCallBroker(inputXml1);
	        		
	            xmlResponse1 = new DMSXmlResponse(outputXml1);
	             System.out.println(xmlResponse1);
	             System.out.println("************Cabinet Disconnected***********************");
	            }
	        catch (Exception e) {
	        	e.printStackTrace();
	        	}
			return null; 
	        	}
	        	    
	        

}
	    


	    	



	

		
