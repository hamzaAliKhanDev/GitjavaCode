package com.newgen.download;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;



import Decoder.BASE64Decoder;



@Path("/createWI")
public class demo {
	static JSONObject json = new JSONObject();
	static JSONObject json2 = new JSONObject();
	inputval value = new inputval();
	
	public static String engineName = "";
    public static String dmsUserName = "";
    public static String dmsUserPswd = "";
    public static String serverIP = "";
    public static String serverPort = "";
    public static String serverType = "";
    public static String jtsPort = "";
    
	static String ApplicantName="";
	static String DateBirth="";
	static String FatherName="";
	static String Address="";
	static String AadharNumber="";
	static String PanNumber="";
	static String FormNumber="";
	static String AppDate="";
	static String AppliedAmount="";
	static String GuaranteeName="";
	static String BankName="";
	static String BranchName="";
	static String BankAccNumber="";
	static String IFSCCode="";
	static String Name="";
	static String SignDate="";
	static String Place="";

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

	public String checkLogin(@HeaderParam("authorization") String auth,String type) throws Exception {
		if(isAuthenticated(auth)){
			
			sendData(type);
			return json.toString();
		}
		else {
			json2.put("Status", "Failed");
			json2.put("ErrorMsg", "Invalid Credentials");
			return json2.toString();
		}
	}
	
	public String sendData(String type) throws Exception{
		value.setType(type);
		String a=value.getType();
		String b=null;
		System.out.println(a);
		JSONObject jsonobj = new JSONObject(a);
		ApplicantName=jsonobj.get("ApplicantName").toString();
		DateBirth=jsonobj.get("DateBirth").toString();
		FatherName=jsonobj.get("FatherName").toString();
		Address=jsonobj.get("Address").toString();
		AadharNumber=jsonobj.get("AadharNumber").toString();
		PanNumber=jsonobj.get("PanNumber").toString();
		FormNumber=jsonobj.get("FormNumber").toString();
		AppDate=jsonobj.get("AppDate").toString();
		AppliedAmount=jsonobj.get("AppliedAmount").toString();
		GuaranteeName=jsonobj.get("GuaranteeName").toString();
		BankName=jsonobj.get("BankName").toString();
		BranchName=jsonobj.get("BranchName").toString();
		BankAccNumber=jsonobj.get("BankAccNumber").toString();
		IFSCCode=jsonobj.get("IFSCCode").toString();
		Name=jsonobj.get("Name").toString();
		SignDate=jsonobj.get("SignDate").toString();
		Place=jsonobj.get("Place").toString();
		
		System.out.println(ApplicantName);
		System.out.println(DateBirth);
		System.out.println(FatherName);
		System.out.println(Address);
		System.out.println(AadharNumber);
		System.out.println(PanNumber);
		System.out.println(FormNumber);
		System.out.println(AppDate);
		System.out.println(AppliedAmount);
		System.out.println(GuaranteeName);
		System.out.println(BankName);
		System.out.println(BranchName);
		System.out.println(BankAccNumber);
		System.out.println(IFSCCode);
		System.out.println(Name);
		System.out.println(SignDate);
		System.out.println(Place);
		
		try {
			startProcessing();
			//json.put("Inside try", "success");
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return json.toString();

	}
	public String startProcessing() throws Exception {
	     
		 ibpsapi obj = new ibpsapi ();
	        String session = obj.connectFlow();
	        System.out.println("Session: " + session);
	        	obj.uploadWI();
	        	obj.DisconnectFlow();
		//json.put("Inside startproc","success");
	        	return json.toString();
	        	
}

	

	public boolean isAuthenticated(String auth) throws IOException{
		String decodeString="";
		String [] authParts = auth.split("\\s");
		String authInfo = authParts[1];
		byte[] bytes = null;
		
		try {
			bytes=new BASE64Decoder().decodeBuffer(authInfo);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		decodeString = new String(bytes);
		System.out.println("DecodeString: "+decodeString);
		
		
		String [] details = decodeString.split(":");
		String userName=details[0];
		String password=details[1];
		System.out.println("uername:"+userName);
 		System.out.println("password:"+password);
		
		
		demo rp1 = new demo();
        
        Properties prop = rp1.readPropertiesFile("config.properties");
 		String user=prop.getProperty("user");
 		String pass=prop.getProperty("password");
 		engineName=prop.getProperty("engineName");
 		dmsUserName=prop.getProperty("dmsUserName");
 		dmsUserPswd=prop.getProperty("dmsUserPswd");
 		serverIP=prop.getProperty("serverIP");
 		serverPort=prop.getProperty("serverPort");
 		serverType=prop.getProperty("serverType");
 		jtsPort=prop.getProperty("jtsPort");
 		System.out.println("uername:"+user);
 		System.out.println("password:"+pass);
 		if(userName.equals(user) && password.equals(pass)) {
		return true;
 		}
 		else {
 			return false;
 		}
		
	}
	
	 public Properties readPropertiesFile(String fileName) throws IOException {
	        InputStream fis = null;
	        Properties prop = null;
	        try {
	            prop = new Properties();
	            fis = this.getClass().getResourceAsStream(fileName);
	 
	            // create Properties class object
	            if (fis != null) {
	                // load properties file into it
	                prop.load(fis);
	            } else {
	                throw new FileNotFoundException("property file '" + fileName + "' not found in the classpath");
	            }
	 
	        } catch (FileNotFoundException e) {
	 
	            e.printStackTrace();
	        } catch (IOException e) {
	 
	            e.printStackTrace();
	        } finally {
	            fis.close();
	        }
	 
	        return prop;
	    }
	
}

