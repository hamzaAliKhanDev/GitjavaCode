package com.newgen.iforms.user;

import com.mysql.cj.xdevapi.Result;
import com.newgen.iforms.EControl;
import java.sql.*;
import com.newgen.iforms.FormDef;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;
import com.newgen.mvcbeans.model.WorkdeskModel;

import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class demo1process implements IFormServerEventHandler {
	String ApplicantName;
	String DateBirth;
	String FatherName;
	String Address;
	String AadharNumber;
	String PanNumber;
	String AppliedAmount;

	List<List<String>> result;

	public void beforeFormLoad(FormDef fd, IFormReference ifr) {
		//
	}

	public JSONArray executeEvent(FormDef arg0, IFormReference arg1, String arg2, String arg3) {

		System.out.println("Java coding");

		return null;
	}

	public String executeServerEvent(IFormReference iform, String arg1, String arg2, String ref) {
		String f1 = "";

		System.out.println("test1: " + arg1);
		System.out.println("test2: " + arg2);
		System.out.println("test3: " + ref);
		
		String filePath = "D:\\iform\\filepath\\LoanApprovalLetter.pdf";
			//String pid = (String) iform.getValue("pid");
			String doctype = "Aadhar";

			try {

				WkHtmlPdf w = new WkHtmlPdf();
				w.generatePDF(filePath, iform);
				//f1 = w.assignToWorkItem(pid, filePath, doctype, iform);

				System.out.println("this is return value:  " + f1);
				return f1;

			} catch (IOException e) {
				// TODO Auto-generated catch block

				e.printStackTrace();
				return f1;
			}

		
		
		
	}

	private void alert(String string) {
		// TODO Auto-generated method stub

	}

	public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1, String arg2) {
		return null;
	}

	public String executeCustomService(FormDef arg0, IFormReference arg1, String arg2, String arg3, String arg4) {
		return null;
	}

	public String getCustomFilterXML(FormDef arg0, IFormReference arg1, String arg2) {
		return null;
	}

	public String setMaskedValue(String arg0, String arg1) {
		return arg1;
	}

	@Override
	public String generateHTML(EControl arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String introduceWorkItemInWorkFlow(IFormReference arg0, HttpServletRequest arg1, HttpServletResponse arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String introduceWorkItemInWorkFlow(IFormReference arg0, HttpServletRequest arg1, HttpServletResponse arg2,
			WorkdeskModel arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	
}