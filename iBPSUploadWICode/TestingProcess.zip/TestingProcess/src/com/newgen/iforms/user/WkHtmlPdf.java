package com.newgen.iforms.user;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import com.newgen.dmsapi.DMSCallBroker;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormCallBroker;
import com.newgen.iforms.xmlapi.IFormXmlResponse;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;



import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;


public class WkHtmlPdf {
	

		List<List<String>> result = null;
		String query = null;
		
		
		public void generatePDF(String filePath,IFormReference iform) throws IOException 
		{
			BufferedReader in = null;
			BufferedWriter bw = null;
			try {
				System.out.println("Inside generatePDF");
			
			//String timeStamp = new SimpleDateFormat("dd-MMM-yyyy").format(new Date());
			StringBuilder contentBuilder = new StringBuilder();
			String tempTemplatePath = "";
			String templatePath= null;
			templatePath ="D:\\iform\\LoanApprovalLetter.HTML";
			System.out.println("tempplatepath"+templatePath);
			
			tempTemplatePath = templatePath.split("\\.")[0];
			tempTemplatePath = tempTemplatePath + "_temp.html";
			
			String str;
			
				in = new BufferedReader(new InputStreamReader(new FileInputStream(templatePath), "UTF8"));
				System.out.println("bufferreader");
				while ((str = in.readLine()) != null) {
					contentBuilder.append(str);
				}
				in.close();
				String content = contentBuilder.toString();
				//LocalDate date = LocalDate.now();
			//	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
				//String duedate = formatter.format(date.plusDays(Long.parseLong(iform.getValue("duedays").toString())));
				content = content.replace("#ApplicantName#",(String)iform.getValue("ApplicantName"));
				content=content.replace("#DateBirth#", (String)iform.getValue("DateBirth"));
				content=content.replace("#FatherName#", (String)iform.getValue("FatherName"));
				content=content.replace("#Address#", (String)iform.getValue("Address"));
				content=content.replace("#AadharNumber#", (String)iform.getValue("AadharNumber"));
				content=content.replace("#PanNumber#", (String)iform.getValue("PanNumber"));
				content=content.replace("#AppliedAmount#", (String)iform.getValue("AppliedAmount"));
				
				
				bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempTemplatePath),"UTF8"));
				bw.write(content);
				bw.close();

				createPdf(tempTemplatePath, filePath);
					
			  
		}
		catch(Exception e) {
			System.out.println("generatePDF"+e.getMessage());
			e.printStackTrace();
		}
			finally {
				in.close();
				bw.close();
			}
		}

		private String createPdf(String htmlpath, String filePath) throws IOException 
		{
			String pdfpath = "";
			InputStreamReader isr = null;
			FileOutputStream fos = null; 
			try 
			{
				File fz = new File(htmlpath);
				String HtmlFileName = fz.getName();
				HtmlFileName.substring(0, HtmlFileName.indexOf("."));
				pdfpath = filePath;    
				File f = new File(pdfpath);
				fos = new FileOutputStream(f);
				FileInputStream fis = new FileInputStream(fz);
				isr = new InputStreamReader(fis, "UTF-8");            
				String wkhtmltopdfPath="D:\\iform\\wkhtmltopdf\\bin\\wkhtmltopdf.exe";  
				wkhtmltopdfPath=wkhtmltopdfPath+" --disable-smart-shrinking -s letter -B 0 -L 0 -R 0 -T 0 --page-width 210 --page-height 332";
				String fullPath=wkhtmltopdfPath+ " \"" + htmlpath + "\"  \"" + pdfpath + "\"";
				System.out.println("full path for html to pdf---------------"+fullPath);           
				try
				{

					Process process = Runtime.getRuntime().exec(fullPath);
					process.waitFor();
					System.out.println("PDF generated successfully");

				}
				catch (Exception e) {
					System.out.println("Error Occured while generating PDF");
					System.out.println("Error Occured while generating PDF--"+e);
					e.printStackTrace();                
				}        
			}
			catch (Exception ex)
			{
				System.out.println("Error Occured while generating PDF");
				System.out.println("Error Occured while generating PDF--"+ex);            
				ex.printStackTrace();
			}    
			finally {
					
						isr.close();
						fos.close();
				
			}
			return pdfpath;      
		}
}

		