package com.newgen.iforms.user;


import com.newgen.iforms.custom.IFormListenerFactory;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.custom.IFormServerEventHandler;


public class demo1 implements IFormListenerFactory {

	@Override
	public IFormServerEventHandler getClassInstance(IFormReference arg0) {
		// TODO Auto-generated method stub
		System.out.println("demo1");
		
		
		return new demo1process();
		
		
	}


}
