package com.newgen.download;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;

import Decoder.BASE64Decoder;



@Path("/demo")
public class demo {
	JSONObject json = new JSONObject();
	inputval value = new inputval();

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

	public String checkLogin(@HeaderParam("authorization") String auth,String type) throws Exception {
		if(isAuthenticated(auth)){
			
			sendData(type);
			return json.toString();
		}
		else {
			json.put("Status", "Failed");
			json.put("ErrorMsg", "Invalid Credentials");
			return json.toString();
		}
	}
	
	public String sendData(String type) throws Exception{
		value.setType(type);
		String a=value.getType();
		String b=null;
		System.out.println("Value of a:"+a);
		
		String[] arrOfStr = a.split(":");
		//System.out.println("value:"+arrOfStr[1]);
		b=arrOfStr[1];
		System.out.println("b:"+b);
		String b1=arrOfStr[2];
		System.out.println("b1:"+b1);
		String b2=arrOfStr[3];
		System.out.println("b2:"+b2);
		String [] b3=b.split(",");
		String b4=b3[0];
		System.out.println("b4:"+b4); //type value in b4
		
		String [] b5=b1.split(",");
		String b6=b5[0];
		System.out.println("b6:"+b6);//fromdate value in b6
		
		String b7=b2.replaceAll("[(){}]", "");
		System.out.println("b7: "+b7);  //todate in b7
		//String result = b. replaceAll("[(){}]", "");
		//System.out.println("result:"+result);
		  JSONObject json1 = new JSONObject(); 
		  json1.put("type", b4);
		  json1.put("fromDate", b6);
		  json1.put("toDate", b7);
		  String c=json1.getString("type"); 
		  String d=json1.getString("fromDate"); 
		  String f=json1.getString("toDate"); 
		  System.out.println("c:"+c.length());
		  System.out.println("fromDate:"+d.length());
		  System.out.println("toDate:"+f.length());
		  
		
		String result1 = c. replace("\"", "");
		System.out.println("result1:"+result1);
		
		String result2=d.replace("\"", "");
		System.out.println("result2:"+result2.length());
		String r3=f.replace("\"", "");
		System.out.println("r3:"+r3);
		String result3 = r3.replaceAll("\\s", "");
		System.out.println("result3:"+result3);
		System.out.println("length:"+result3.length());
		try {
			showrecord(result1,result2,result3);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("json"+json.toString());
		return json.toString();

	}

	public JSONObject showrecord(String result1,String result2,String result3) throws Exception {
		Connection conn = DBconnect.getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = null;
		//Giving total count if wrong format of date is given
		if (result1.equalsIgnoreCase("All")) {
			rs = st.executeQuery("select count(1),todepartment from ext_egov_tbl where initiatedon >= '"+result2+"' AND initiatedon <= DATEADD(dd, 1, '"+result3+"') group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else if(result1.equalsIgnoreCase("File")) {
			rs = st.executeQuery("select count(1),todepartment from EXT_EGOV_TBL WHERE type ='File' and initiatedon >= '"+result2+"' AND initiatedon <= DATEADD(dd, 1, '"+result3+"') group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else if(result1.equalsIgnoreCase("DAK")) {
			rs = st.executeQuery("select count(1),todepartment from EXT_EGOV_TBL WHERE type ='DAK' and initiatedon >= '"+result2+"' AND initiatedon <= DATEADD(dd, 1, '"+result3+"') group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else if(result1.equalsIgnoreCase("Note")) {
			rs = st.executeQuery("select count(1),todepartment from EXT_EGOV_TBL WHERE type ='Note' and initiatedon >= '"+result2+"' AND initiatedon <= DATEADD(dd, 1, '"+result3+"') group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else {
			json.put("Status", "Failed");
			json.put("ErrorMsg", "Value entered "+result1+" is not valid.Enter valid input!");
		}
		// dbout= "{";
		System.out.println("value:"+value);
		System.out.println("rs"+rs.toString());
		try {
		while (rs.next()) {
			System.out.println("in rs while");
			String a = rs.getString(2);
			String b = rs.getString(1);
			json.put(a, b);
			System.out.println("In while loop" + json.toString());
			
		}
		}
		catch(Exception ex) {
			json.put("Status","Failed");
			json.put("ErrorMsg","No data Found for given time period OR "+ex.getLocalizedMessage()+"Enter correct date time format(YYYY-MM-DD)");
		}
		// dbout=dbout+"}";
		return json;
	}

	public boolean isAuthenticated(String auth) throws IOException{
		String decodeString="";
		String [] authParts = auth.split("\\s");
		String authInfo = authParts[1];
		byte[] bytes = null;
		
		try {
			bytes=new BASE64Decoder().decodeBuffer(authInfo);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		decodeString = new String(bytes);
		System.out.println("DecodeString: "+decodeString);
		
		
		String [] details = decodeString.split(":");
		String userName=details[0];
		String password=details[1];
		System.out.println("uername:"+userName);
 		System.out.println("password:"+password);
		
		
		demo rp1 = new demo();
        
        Properties prop = rp1.readPropertiesFile("config.properties");
 		String user=prop.getProperty("user");
 		String pass=prop.getProperty("password");
 		System.out.println("uername:"+user);
 		System.out.println("password:"+pass);
 		if(userName.equals(user) && password.equals(pass)) {
		return true;
 		}
 		else {
 			return false;
 		}
		
	}
	
	 public Properties readPropertiesFile(String fileName) throws IOException {
	        InputStream fis = null;
	        Properties prop = null;
	        try {
	            prop = new Properties();
	            fis = this.getClass().getResourceAsStream(fileName);
	 
	            // create Properties class object
	            if (fis != null) {
	                // load properties file into it
	                prop.load(fis);
	            } else {
	                throw new FileNotFoundException("property file '" + fileName + "' not found in the classpath");
	            }
	 
	        } catch (FileNotFoundException e) {
	 
	            e.printStackTrace();
	        } catch (IOException e) {
	 
	            e.printStackTrace();
	        } finally {
	            fis.close();
	        }
	 
	        return prop;
	    }
	
}
