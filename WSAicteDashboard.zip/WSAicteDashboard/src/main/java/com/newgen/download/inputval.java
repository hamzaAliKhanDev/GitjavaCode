package com.newgen.download;

public class inputval {
	private String type;
	
	public String getType() {
		return type;
	}
	public void setType(String val) {
		this.type=val;
	}
}
