package com.newgen.download;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;

import Decoder.BASE64Decoder;



@Path("/DashboardData")
public class demo {
	JSONObject json = new JSONObject();
	inputval value = new inputval();

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

	public String checkLogin(@HeaderParam("authorization") String auth,String type) throws Exception {
		if(isAuthenticated(auth)){
			
			sendData(type);
			return json.toString();
		}
		else {
			json.put("Status", "Failed");
			json.put("ErrorMsg", "Invalid Credentials");
			return json.toString();
		}
	}
	
	public String sendData(String type) throws Exception{
		value.setType(type);
		String a=value.getType();
		String b=null;
		String[] arrOfStr = a.split(":");
		b=arrOfStr[1];
		String b1=arrOfStr[2];
		String b2=arrOfStr[3];
		String [] b3=b.split(",");
		String b4=b3[0];
		String [] b5=b1.split(",");
		String b6=b5[0];
		String b7=b2.replaceAll("[(){}]", "");
		
		JSONObject json1 = new JSONObject(); 
		json1.put("type", b4);
		json1.put("fromDate", b6);
		json1.put("toDate", b7);
		
		String c=json1.getString("type"); 
		String d=json1.getString("fromDate"); 
		String f=json1.getString("toDate"); 		
		String result1 = c. replace("\"", "");
		String result2=d.replace("\"", "");
		String r3=f.replace("\"", "");
		String result3 = r3.replaceAll("\\s", "");
		//result1=result1.toUpperCase();
		result2=result2.toUpperCase();
		result3=result3.toUpperCase();
		System.out.println("result1:"+result1);
		System.out.println("result2:"+result2);
		System.out.println("result3:"+result3);
		try {
			showrecord(result1,result2,result3);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return json.toString();

	}

	public JSONObject showrecord(String result1,String result2,String result3) throws Exception {
	
		Connection conn = DBconnect.getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = null;
		//Giving total count if wrong format of date is given
		try {
		if (result1.equalsIgnoreCase("All")) {
			rs = st.executeQuery("select count(1),todepartment from ext_egov_tbl where initiatedon >= to_date('"+result2+"','DD-MM-YYYY') AND initiatedon <= to_date('"+result3+"','DD-MM-YYYY')+1 group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else if(result1.equalsIgnoreCase("File")) {
			rs = st.executeQuery("select count(1),todepartment from ext_egov_tbl,ddt_4 where folderid=folddocindex and todepartment is not null and initiatedon >= to_date('"+result2+"','DD-MM-YYYY') AND initiatedon <= to_date('"+result3+"','DD-MM-YYYY')+1 group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else if(result1.equalsIgnoreCase("DAK")) {
			rs = st.executeQuery("select count(1),todepartment from ext_egov_tbl,ddt_3 where dakid=folddocindex and todepartment is not null and initiatedon >= to_date('"+result2+"','DD-MM-YYYY') AND initiatedon <= to_date('"+result3+"','DD-MM-YYYY')+1 group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		else if(result1.equalsIgnoreCase("Note")) {
			rs = st.executeQuery("select count(1),todepartment from ext_egov_tbl,ddt_5 where dakid=folddocindex and todepartment is not null and initiatedon >= to_date('"+result2+"','DD-MM-YYYY') AND initiatedon <= to_date('"+result3+"','DD-MM-YYYY')+1 group by todepartment");
			json.put("Status", "Success");
			json.put("ErrorMsg", "Null");
		}
		/*else {
			json.put("Status", "Failed");
			json.put("ErrorMsg", "Value entered "+result1+" is not valid.Enter valid input!");
			
		}*/
		
		try {
		while (rs.next()) {
			String a = rs.getString(2);
			String b = rs.getString(1);
			json.put(a, b);	
		}
	}
		catch(Exception ex1) {
			json.put("Status","Failed");
			json.put("Error","Value entered "+result1+" is not valid.Enter valid input!");
		}
		}
		catch(Exception ex) {
			json.put("Status","Failed");
			json.put("ErrorMsg","No data Found for given time period.Check the input values.Accepted values-{'type':'file','dak','note','all'} and date time format(DD-MM-YYYY)");
		}
		
		return json;
	}

	public boolean isAuthenticated(String auth) throws IOException{
		String decodeString="";
		String [] authParts = auth.split("\\s");
		String authInfo = authParts[1];
		byte[] bytes = null;
		
		try {
			bytes=new BASE64Decoder().decodeBuffer(authInfo);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		decodeString = new String(bytes);
				
		String [] details = decodeString.split(":");
		String userName=details[0];
		String password=details[1];
		
		demo rp1 = new demo();
        
        Properties prop = rp1.readPropertiesFile("config.properties");
 		String user=prop.getProperty("user");
 		String pass=prop.getProperty("password");
 
 		if(userName.equals(user) && password.equals(pass)) {
		return true;
 		}
 		else {
 			return false;
 		}
		
	}
	
	 public Properties readPropertiesFile(String fileName) throws IOException {
	        InputStream fis = null;
	        Properties prop = null;
	        try {
	            prop = new Properties();
	            fis = this.getClass().getResourceAsStream(fileName);
	 
	            // create Properties class object
	            if (fis != null) {
	                // load properties file into it
	                prop.load(fis);
	            } else {
	                throw new FileNotFoundException("property file '" + fileName + "' not found in the classpath");
	            }
	 
	        } catch (FileNotFoundException e) {
	 
	            e.printStackTrace();
	        } catch (IOException e) {
	 
	            e.printStackTrace();
	        } finally {
	            fis.close();
	        }
	 
	        return prop;
	    }
	
}
