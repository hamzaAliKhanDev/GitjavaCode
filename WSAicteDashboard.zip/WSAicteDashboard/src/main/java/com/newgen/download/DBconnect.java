package com.newgen.download;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBconnect {
	 private static Connection connection;		//Connection class is required for establishing a connection between Java Application and the Database Server.
	 private static String conurl;
	 private static String driverClass;
	 private static String dbuser;
	 private static String dbpassword;
	  
	    public static Connection getConnection() throws Exception
	    {   
	    	
	    	DBconnect rp = new DBconnect();
	        
	        Properties prop = rp.readPropertiesFile("config.properties");
	        conurl=prop.getProperty("connectionUrl");
			driverClass=prop.getProperty("driverClass");
	 		dbuser=prop.getProperty("dbUserName");
	 		dbpassword=prop.getProperty("dbPassword");
	    	
	        Class.forName(driverClass);	
	        connection = DriverManager.getConnection(conurl,dbuser,dbpassword);
	        
	        return connection;
}
	    
	    public Properties readPropertiesFile(String fileName) throws IOException {
	        InputStream fis = null;
	        Properties prop = null;
	        try {
	            prop = new Properties();
	            fis = this.getClass().getResourceAsStream(fileName);
	 
	            // create Properties class object
	            if (fis != null) {
	                // load properties file into it
	                prop.load(fis);
	            } else {
	                throw new FileNotFoundException("property file '" + fileName + "' not found in the classpath");
	            }
	 
	        } catch (FileNotFoundException e) {
	 
	            e.printStackTrace();
	        } catch (IOException e) {
	 
	            e.printStackTrace();
	        } finally {
	            fis.close();
	        }
	 
	        return prop;
	    }
	 

}