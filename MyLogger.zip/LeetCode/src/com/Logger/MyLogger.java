package com.Logger;

import java.io.File;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class MyLogger {
	private static Logger logger=Logger.getLogger("MyLog");
	
	public static void init() {
		FileHandler fh;
		 
		try {
			File f1 = new File(System.getProperty("user.dir") + "\\Logs");
			if(!f1.exists()) {
				f1.mkdir();
			}

			String path=System.getProperty("user.dir") + "\\Logs\\MyLogger.log";
			//logger.setLevel(Level.WARNING);;
			fh=new FileHandler(path,true);
			getLogger().addHandler(fh);
			SimpleFormatter formatter=new SimpleFormatter();
			fh.setFormatter(formatter);
			getLogger().info("Logger Initialised");
		
		}
		catch(Exception e) {
			getLogger().log(Level.WARNING,"Exception :: ",e);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		init();
		try {
			int a=10/0;
		}
		catch(Exception e) {
			getLogger().log(Level.WARNING,"Exception :: ",e);
		}
		getLogger().info("End of program");
	}

	public static Logger getLogger() {
		return logger;
	}

	public static void setLogger(Logger logger) {
		MyLogger.logger = logger;
	}

}
