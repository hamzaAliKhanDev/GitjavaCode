prop = {
  // This can have nested stuff, arrays, etc.  color: 'red',
  user: 'admin',
  password: 'system123#',
 
}