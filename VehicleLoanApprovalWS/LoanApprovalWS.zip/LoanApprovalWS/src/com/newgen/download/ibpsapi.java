package com.newgen.download;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.jar.JarException;

import org.json.JSONObject;

import com.newgen.dmsapi.DMSCallBroker;
import com.newgen.dmsapi.DMSInputXml;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.NGException;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.omni.wf.util.app.NGEjbClient;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import Jdts.Client.JtsConnection;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;
import ISPack.CImageServer;

public class ibpsapi extends demo {
	
	String sessionId = "";
    String volumeid ="";
    static String folderIndex = null;
    static String processInstanceID = null;
    static String docType = null;

	    public static NGEjbClient ngEJBClient;
	   
	    public ibpsapi() throws Exception {
	        /*engineName = "hamzacab";
	        dmsUserName = "padmin";
	        dmsUserPswd = "system123#";
	        serverIP = "192.168.149.192";
	        serverPort = "8080";
	        serverType = "jbosseap";
	        jtsPort = "3333";*/
	    }

	    public String connectFlow() {
	        String outputXml = null;
	        DMSXmlResponse xmlResponse = null;
	        
	        
	        String inputXml = "<? xml version=\"1.0\"?>"
	                + "<NGOConnectCabinet_Input>"
	                + "<Option>NGOConnectCabinet</Option><CabinetName>"
	                + engineName + "</CabinetName><UserName>"
	                + dmsUserName + "</UserName><UserPassword>"
	                + dmsUserPswd + "</UserPassword>"
	                + "<Scope>ADMIN</Scope>"
	                + "<UserExist>N</UserExist><CurrentDateTime></CurrentDateTime><UserType>U</UserType>"
	                + "<MainGroupIndex>0</MainGroupIndex><Locale></Locale></NGOConnectCabinet_Input>";
	        		System.out.println(inputXml);
	        		//outputXml = DMSCallBroker.execute(inputXml.toString(), "192.168.136.154", Integer.parseInt("3333"), "8859_1", 1, false);
	        try {	
	        		outputXml= executeWithCallBroker(inputXml);
	        		
	            xmlResponse = new DMSXmlResponse(outputXml);
	             // System.out.println(xmlResponse);
	            if (xmlResponse.getVal("Status").equalsIgnoreCase("0")) {
	                sessionId = xmlResponse.getVal("UserDBId");
	              // System.out.println(sessionId);
	                volumeid=xmlResponse.getVal("ImageVolumeIndex");
	                System.out.println(sessionId);
	                return sessionId+"_"+volumeid;
	            }else {
	                return null;
	            }}
	        catch (Exception e) {
	        	return null;
	        	} finally {
	        	if (xmlResponse != null) {
	        	xmlResponse = null;
	        	}
	        	}
	        	}
	        
	            public static String executeWithCallBroker(String inputXml) throws NGException, IOException {
	            	String outputXml = "";
	            	System.out.println("before callbroker");
	            	outputXml = DMSCallBroker.execute(inputXml, serverIP, Short.parseShort(jtsPort), "8859_1",1,false);
	            	System.out.println("after call broker");

	            	//System.out.println(outputXml);
	            	return outputXml;
	            	
	            }
	        public JSONObject uploadWI() throws JPISException{
	    	
	    	
	    	DMSXmlResponse xmlResponse = null;
	    	StringBuffer inputXml = new StringBuffer();
	    	String outputXml = null;
	    	String mainCode = null;
	    	
	    	String documents = null;

	    	System.out.println("ApplicantName"+ApplicantName);
	    	//=======Upload Call===========//
	    	
	    	try {
	    		inputXml.append("<WFUploadWorkItem_Input>");
	    		inputXml.append("<Option>WFUploadWorkItem</Option>");
	    		inputXml.append("<EngineName>" + engineName + "</EngineName>");
	    		inputXml.append("<SessionId>" + sessionId + "</SessionId>");
	    		inputXml.append("<ProcessDefId>" + "1004" + "</ProcessDefId>");
	    		inputXml.append("<QueueId>" + "2012" + "</QueueId>");
	    		inputXml.append("<InitiateFromActivityId></InitiateFromActivityId>");
	    		inputXml.append("<InitiateAlso>Y</InitiateAlso>");
	    		inputXml.append("<VariantId>"+"0"+"</VariantId>");
	    		inputXml.append("<UserDefVarFlag>Y</UserDefVarFlag>");
	    		inputXml.append("<Documents></Documents>");
	    		//inputXml.append("<Attributes></Attributes>");
	    		inputXml.append("<Attributes><ApplicantName>"+ApplicantName+"</ApplicantName><DateBirth>"+DateBirth+"</DateBirth><FatherName>"+FatherName+"</FatherName><Address>"+Address+"</Address><AadharNumber>"+AadharNumber+"</AadharNumber><PanNumber>"+PanNumber+"</PanNumber><OccupationType>"+OccupationType+"</OccupationType><FormNumber>"+FormNumber+"</FormNumber><AppDate>"+AppDate+"</AppDate><GuarantorName>"+GuarantorName+"</GuarantorName><Name>"+ApplicantName+"</Name><Place>"+Place+"</Place><SigninDate>"+SigninDate+"</SigninDate></Attributes>");
	    		inputXml.append("</WFUploadWorkItem_Input>");

	    				System.out.println(inputXml);
	    				

	    	 
	    	
	    	 
	    	outputXml = ibpsapi.executeWithCallBroker(inputXml.toString());
	    	System.out.println("+++++++++upload workitem++++++++++++");
	    	System.out.println(outputXml);
	    	
	    	xmlResponse = new DMSXmlResponse(outputXml);
	    	mainCode = xmlResponse.getVal("MainCode");
	    	folderIndex = xmlResponse.getVal("FolderIndex");



	    	if (mainCode.equals("0")) {
	    	processInstanceID = xmlResponse.getVal("ProcessInstanceId");
	    	System.out.println(processInstanceID);
	    	String myDirectoryPath="D:\\apache-tomcat-9.0.65-windows-x64\\apache-tomcat-9.0.65\\tmpfiles";
	    	File dir = new File(myDirectoryPath);
	    	  File[] directoryListing = dir.listFiles();
	    	  if (directoryListing != null) {
	    	    for (File child : directoryListing) {
	    	    	System.out.println(child.getName());
	    	    	docType=child.getName();
	  	    	  if(NGOCAddDocument(processInstanceID,child.toString(),docType)) {
	  	    		  child.delete();
	  	    	  }
	    	    }
	    	  } 
	    	  
	    	/*if(!ITRDocPath.equalsIgnoreCase("") || !ITRDocPath.equalsIgnoreCase(null)) {
	    		ITRDocPath="C:\\Users\\hamza.khan\\Downloads\\"+ITRDocPath;
	    		docType="ITR";
	    		System.out.println("inside if");
	    		NGOCAddDocument(processInstanceID,ITRDocPath,docType);
	    		System.out.println("ITR Added successfully!!");
	    	}
	    	
	    	if(!SalaryDocPath.equalsIgnoreCase("") || !SalaryDocPath.equalsIgnoreCase(null)) {
	    		SalaryDocPath="C:\\Users\\hamza.khan\\Downloads\\"+SalaryDocPath;
	    		docType="SalarySlip";
	    		System.out.println("inside if");
	    		NGOCAddDocument(processInstanceID,SalaryDocPath,docType);
	    		System.out.println("SalarySlip Added successfully!!");
	    	}
	    	
	    	if(!Form16DocPath.equalsIgnoreCase("") || !Form16DocPath.equalsIgnoreCase(null)) {
	    		Form16DocPath="C:\\Users\\hamza.khan\\Downloads\\"+Form16DocPath;
	    		docType="Form16D";
	    		System.out.println("inside if");
	    		NGOCAddDocument(processInstanceID,Form16DocPath,docType);
	    		System.out.println("Form16 Added Successfully!!");
	    	}
	    	
	    	if(!BankStatementDocPath.equalsIgnoreCase("") || !BankStatementDocPath.equalsIgnoreCase(null)) {
	    		BankStatementDocPath="C:\\Users\\hamza.khan\\Downloads\\"+Form16DocPath;
	    		docType="BankStatement";
	    		System.out.println("inside if");
	    		NGOCAddDocument(processInstanceID,BankStatementDocPath,docType);
	    		System.out.println("BankStatement Added Successfully!!");
	    	}*/
	    	json.put("Status","Workitem created Succesfully!");
	    	json.put("OutputXML",outputXml);
	    	
	    	
	    	} 
	    	else {
	    		
	    		json.put("Status","Failed!");
		    	json.put("OutputXML",outputXml);
		    	
	    	
	    	}
	    	} catch (Exception e) {
	    	
	    		e.printStackTrace();
	    	} finally {
	    	if (xmlResponse != null) {
	    	xmlResponse = null;
	    	}
	    	}
	    	return json;
	    	}
	  
	        public String DisconnectFlow() {
		        String outputXml1 = null;
		        DMSXmlResponse xmlResponse1 = null;
	        String inputXml1 = "<? xml version=\"1.0\"?>"
	                + "<NGODisconnectCabinet_Input>"
	                + "<Option>NGODisconnectCabinet</Option><CabinetName>"
	                + engineName + "</CabinetName><UserDBId>"
	                + sessionId + "</UserDBId></NGOConnectCabinet_Input>";
	        		System.out.println(inputXml1);
	        		//outputXml = DMSCallBroker.execute(inputXml.toString(), "192.168.136.154", Integer.parseInt("3333"), "8859_1", 1, false);
	        try {	
	        		outputXml1= executeWithCallBroker(inputXml1);
	        		
	            xmlResponse1 = new DMSXmlResponse(outputXml1);
	             System.out.println(xmlResponse1);
	             System.out.println("************Cabinet Disconnected***********************");
	            }
	        catch (Exception e) {
	        	e.printStackTrace();
	        	}
			return null; 
	        	}
	        
public boolean NGOCAddDocument(String pid, String filePath, String doctype) throws IOException, NumberFormatException, JPISException {
	            
			try {
				  System.out.println(" Add document API");
		           DMSInputXml objInputXml = new DMSInputXml();

		           String imageVolumeId = "1";
		           JtsConnection connection = null;
		           ISPack.ISUtil.JPISIsIndex isIndex = new ISPack.ISUtil.JPISIsIndex();
		           String simgVolId1 = "";
		           String simgDocId = "";
		           String strDocumentName = "";
		           String strDocumenttype = "";
		           String sImageorNImage = "";
		           int nNoOfPages = 1;
		           String docExt="pdf";
		           File fileDir = new File(filePath);
					String fileName = fileDir.getName();
		   JPDBRecoverDocData docDBData = new JPDBRecoverDocData();

		           System.out.println("Before add documnet on image server");
		           
					CPISDocumentTxn.AddDocument_MT(connection, serverIP, Short.parseShort(jtsPort), engineName, Short.parseShort(volumeid), fileDir.getAbsolutePath(), docDBData, null, isIndex);
		           System.out.println("after add documnet on image server:" + isIndex.m_sVolumeId + "#" + isIndex.m_nDocIndex);
		   simgVolId1 = simgVolId1 + isIndex.m_sVolumeId;
		   simgDocId = simgDocId +isIndex.m_sVolumeId;
		   int m_nDocumentSize = docDBData.m_nDocumentSize;
		   String newisIndex = isIndex.m_nDocIndex + "#" + isIndex.m_sVolumeId;

		   /*String inputXml = "<?xml version='1.0'?><NGOAddDocument_Input><Option>NGOAddDocument</Option><CabinetName>"
					+ engineName + "</CabinetName><UserDBId>" + sessionId
					+ "</UserDBId><GroupIndex>0</GroupIndex><ParentFolderIndex>" + folderIndex
					+ "</ParentFolderIndex><DocumentName>" + docType
					+ "</DocumentName><CreatedByAppName></CreatedByAppName><Comment>"
					+ fileName + "</Comment><VolumeIndex>" + volumeid
					+ "</VolumeIndex><FilePath></FilePath><ProcessDefId>" +pid
					+ "</ProcessDefId><DataDefinition></DataDefinition><ISIndex>"+ isIndex.m_nDocIndex+ "#" + isIndex.m_sVolumeId+"#"
					+ "</ISIndex><NoOfPages></NoOfPages><VersionFlag>Y</VersionFlag><DocumentType>"+"N"+"</DocumentType><DocumentSize></DocumentSize></NGOAddDocument_Input>";*/
		   fileName = fileName.substring(0, fileName.toLowerCase().indexOf(".pdf".toLowerCase()));
		   String inputXml = "<?xml version='1.0'?><NGOAddDocument_Input><Option>NGOAddDocument</Option><CabinetName>"
	               + engineName + "</CabinetName><UserDBId>" + sessionId
	               + "</UserDBId><GroupIndex>0</GroupIndex><ParentFolderIndex>" + folderIndex
	               + "</ParentFolderIndex><DocumentName>" + docType
	               + "</DocumentName><CreatedByAppName>" + docExt + "</CreatedByAppName><Comment>"
	               + fileName + "</Comment><VolumeIndex>" + volumeid
	               + "</VolumeIndex><FilePath></FilePath><ProcessDefId>" +pid
	               + "</ProcessDefId><DataDefinition></DataDefinition><ISIndex>" + newisIndex
	               + "</ISIndex><NoOfPages></NoOfPages><VersionFlag>Y</VersionFlag><DocumentType>"+"N"+"</DocumentType><DocumentSize>"
	               + m_nDocumentSize + "</DocumentSize></NGOAddDocument_Input>";
		   System.out.println("NGOBlkLoad InputXML:: " + inputXml.toString());
		   String sOutputXmlUpload = "";

		   sOutputXmlUpload = DMSCallBroker.execute(inputXml.toString(), "192.168.149.192", Integer.parseInt("3333"), "8859_1", 1, false);
		   DMSXmlResponse xmlResponseUpload = new DMSXmlResponse(sOutputXmlUpload);

		   System.out.println(sOutputXmlUpload);
	   return true;
			} 
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		}
	        	    
	        

}
	    


	    	



	

		
