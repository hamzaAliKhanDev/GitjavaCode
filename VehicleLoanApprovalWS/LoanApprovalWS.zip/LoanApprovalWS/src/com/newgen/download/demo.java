package com.newgen.download;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONException;
import org.json.JSONObject;

import Decoder.BASE64Decoder;
import ISPack.ISUtil.JPISException;



@Path("/LoanApprovalTest")
public class demo {
	static JSONObject json = new JSONObject();
	static JSONObject json2 = new JSONObject();
	inputval value = new inputval();
	
	public static String engineName = "";
    public static String dmsUserName = "";
    public static String dmsUserPswd = "";
    public static String serverIP = "";
    public static String serverPort = "";
    public static String serverType = "";
    public static String jtsPort = "";
    
	static String ApplicantName="";
	static String DateBirth="";
	static String FatherName="";
	static String Address="";
	static String AadharNumber="";
	static String PanNumber="";
	static String OccupationType="";  //
	static String FormNumber="";
	static String AppDate="";
	//static String AppAmount="";
	static String GuarantorName="";
	//static String BankName="";
	//static String BranchName="";
	//static String AccountNumber="";
	//static String IFSCCode="";
	//static String Name="";
	static String SigninDate="";
	static String Place="";
	static String ITRDocPath="";
	static String SalaryDocPath="";
	static String Form16DocPath="";
	static String BankStatementDocPath="";
	
	
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	
	/*public String checkLogin(@HeaderParam("authorization") String auth,String type) throws Exception, JPISException{
		if(isAuthenticated(auth)){
			//saveToDisk(uploadedInputStream,fileDetail);
			sendData(type);
			return json.toString();
		}
		else {
			json2.put("Status", "Failed");
			json2.put("ErrorMsg", "Invalid Credentials");
			return json2.toString();
		}
	}*/

	public String sendData(String type) throws Exception, JPISException{
		value.setType(type);
		String a=value.getType();
		String b=null;
		//System.out.println("a-->"+a);
		String []sp=a.split("\n");
		for(int i=3;i<sp.length;) {
			System.out.println(sp[i]);
			
			i=i+4;
		}
		/*String [] sp= {"ApplicantName","DateBirth","FatherName","Address","AadharNumber","PanNumber","OccupationType","FormNumber","AppDate","GuarantorName","SigninDate","Place"};
		int i=0;
		int j=3;
		while(i<sp.length) {
			sp[0]=sp[j];
			i++;
			j=j+4;
		}*/
		
		/*JSONObject jsonobj = new JSONObject(a);
		//System.out.println("JSONOb-->"+jsonobj.toString());*/
		ApplicantName=sp[3];
		DateBirth=sp[7];
		FatherName=sp[11];
		Address=sp[15];
		AadharNumber=sp[19];
		PanNumber=sp[23];
		OccupationType=sp[27];
		FormNumber=sp[31];
		AppDate=sp[35];
		GuarantorName=sp[39];
		SigninDate=sp[43];
		Place=sp[47];
		//AppAmount=jsonobj.get("AppliedAmount").toString();
		//BankName=jsonobj.get("BankName").toString();
		//BranchName=jsonobj.get("BranchName").toString();
		//AccountNumber=jsonobj.get("BankAccNumber").toString();
		//IFSCCode=jsonobj.get("IFSCCode").toString();
		//Name=jsonobj.get("Name").toString();
		//ITRDocPath=jsonobj.get("ITRDocPath").toString();
		//SalaryDocPath=jsonobj.get("SalaryDocPath").toString();
		//Form16DocPath=jsonobj.get("Form16DocPath").toString();
		//BankStatementDocPath=jsonobj.get("BankStatementDocPath").toString();
		
		System.out.println(ApplicantName);
		System.out.println(DateBirth);
		System.out.println(FatherName);
		System.out.println(Address);
		System.out.println(AadharNumber);
		System.out.println(PanNumber);
		System.out.println(FormNumber);
		System.out.println(AppDate);
		System.out.println(OccupationType);
		System.out.println(GuarantorName);
		System.out.println(SigninDate);
		System.out.println(Place);
		//System.out.println(BankName);
		//System.out.println(BranchName);
		//System.out.println(BankAccNumber);
		//System.out.println(IFSCCode);
		//System.out.println(Name);
		//System.out.println(ITRDocPath);
		//System.out.println(SalaryDocPath);
		//System.out.println(Form16DocPath);
		//System.out.println(BankStatementDocPath);
		demo rp1 = new demo();
		Properties prop = rp1.readPropertiesFile("config.properties");
		engineName=prop.getProperty("engineName");
 		dmsUserName=prop.getProperty("dmsUserName");
 		dmsUserPswd=prop.getProperty("dmsUserPswd");
 		serverIP=prop.getProperty("serverIP");
 		serverPort=prop.getProperty("serverPort");
 		serverType=prop.getProperty("serverType");
 		jtsPort=prop.getProperty("jtsPort");
		
		try {
			startProcessing();
			//json.put("Inside try", "success");
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return json.toString();

	}
	public String startProcessing() throws Exception, JPISException {
	     
		 ibpsapi obj = new ibpsapi ();
	        String session = obj.connectFlow();
	        System.out.println("Session: " + session);
					obj.uploadWI();
	        	obj.DisconnectFlow();
		//json.put("Inside startproc","success");
	        	return json.toString();
	        	
}

	

	public boolean isAuthenticated(String auth) throws IOException{
		String decodeString="";
		String [] authParts = auth.split("\\s");
		String authInfo = authParts[1];
		byte[] bytes = null;
		
		try {
			bytes=new BASE64Decoder().decodeBuffer(authInfo);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		decodeString = new String(bytes);
		System.out.println("DecodeString: "+decodeString);
		
		
		String [] details = decodeString.split(":");
		String userName=details[0];
		String password=details[1];
		System.out.println("uername:"+userName);
 		System.out.println("password:"+password);
		
		
		demo rp1 = new demo();
        
        Properties prop = rp1.readPropertiesFile("config.properties");
 		String user=prop.getProperty("user");
 		String pass=prop.getProperty("password");
 		engineName=prop.getProperty("engineName");
 		dmsUserName=prop.getProperty("dmsUserName");
 		dmsUserPswd=prop.getProperty("dmsUserPswd");
 		serverIP=prop.getProperty("serverIP");
 		serverPort=prop.getProperty("serverPort");
 		serverType=prop.getProperty("serverType");
 		jtsPort=prop.getProperty("jtsPort");
 		System.out.println("uername:"+user);
 		System.out.println("password:"+pass);
 		if(userName.equals(user) && password.equals(pass)) {
		return true;
 		}
 		else {
 			return false;
 		}
		
	}
	
	 public Properties readPropertiesFile(String fileName) throws IOException {
	        InputStream fis = null;
	        Properties prop = null;
	        try {
	            prop = new Properties();
	            fis = this.getClass().getResourceAsStream(fileName);
	 
	            // create Properties class object
	            if (fis != null) {
	                // load properties file into it
	                prop.load(fis);
	            } else {
	                throw new FileNotFoundException("property file '" + fileName + "' not found in the classpath");
	            }
	 
	        } catch (FileNotFoundException e) {
	 
	            e.printStackTrace();
	        } catch (IOException e) {
	 
	            e.printStackTrace();
	        } finally {
	            fis.close();
	        }
	 
	        return prop;
	    }
	
	
}

