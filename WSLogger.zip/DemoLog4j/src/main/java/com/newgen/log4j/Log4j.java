package com.newgen.log4j;

import java.io.File;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;
import java.util.logging.Logger;


public class Log4j {
	private static Logger logger=Logger.getLogger("MyLog");
	 public static void init() {
		 
			FileHandler fh;
			 System.out.println("inside init");
			 try {
					//File f1 = new File(System.getProperty("user.dir") + "\\Logs");
				 	File f1 = new File("D:\\Logs");
					if(!f1.exists()) {
						f1.mkdir();
						System.out.println(f1.mkdir());
					}

					//String path=System.getProperty("user.dir") + "\\Logs\\Server.log";
					String path="D:\\Logs\\ServerLog.txt";
					logger.setLevel(Level.INFO);;
					fh=new FileHandler(path,true);
					getLog().addHandler(fh);
					SimpleFormatter formatter=new SimpleFormatter();
					fh.setFormatter(formatter);
					getLog().info("Logger Initialised");
					//File f2 = new File(path);
					
				}
				catch(Exception e) {
					getLog().log(Level.WARNING,"Exception :: ",e);
				}
		}
		public static Logger getLog() {
			return logger;
		}

		public static void setLog(Logger logger) {
			Log4j.logger = logger;
		}



}
