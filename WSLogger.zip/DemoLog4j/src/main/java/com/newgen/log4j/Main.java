package com.newgen.log4j;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONException;
import org.json.JSONObject;

@Path("/log4j")
public class Main extends Log4j{
	static valueFromJson inputval = new valueFromJson();
	//static JSONObject outputJson = new JSONObject();
	static String outputXML="";
	static String name="";
	static String email="";
	static String address="";
	static String mobileNumber="";
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_XML)
	public static String outputJson(String input) throws JSONException {
			init();
			try {
			inputval.setJson(input);
			String inputJson=inputval.getJson();
			JSONObject outputJsonObj = new JSONObject(inputJson);
			name=outputJsonObj.get("name").toString();
			email=outputJsonObj.get("email").toString();
			address=outputJsonObj.get("address").toString();
			mobileNumber=outputJsonObj.get("mobileNumber").toString();
			try {
			
			if(name.isBlank() ||email.isBlank() ||address.isBlank() ||mobileNumber.isEmpty()){
				//outputJson.put("Status", "Terminated");
				//outputJson.put("Error","No field can be left blank");
				outputXML="<?xml version='1.0'?>"+"<Status>Failed</Status>"+"<Error>No field can be left blank!</Error>";
				getLog().severe(outputXML);
			}
			/*for(int i=0;i<mobileNumber.length();i++) {
				if(mobileNumber.charAt(i)!='0'||mobileNumber.charAt(i)!='1'||mobileNumber.charAt(i)!='2'||mobileNumber.charAt(i)!='3'||mobileNumber.charAt(i)!='4'||mobileNumber.charAt(i)!='5'||mobileNumber.charAt(i)!='6'||mobileNumber.charAt(i)!='7'||mobileNumber.charAt(i)!='8'||mobileNumber.charAt(i)!='9') {
					outputJson.put("Status", "Terminated");
					outputJson.put("Error","mobileNumber cannot contain alphanumeric characters");
				}
			}*/
			else {
				//outputJson.put("Status", "Success");
				//outputJson.put("Error", "Null");
				outputXML="<?xml version='1.0'?><Status>Success</Status><Error>Null</Error>";
				getLog().info(outputXML);
			}
			}
			catch(Exception ex) {
				//outputJson.put("Error Msg", ex.getLocalizedMessage());
				outputXML="<?xml version='1.0'?><Status>Failed</Status><Error>"+ex.getLocalizedMessage()+"</Error>";
				getLog().severe(outputXML);
	
			}
			}
			catch(Exception e) {
				//outputJson.put("Status","Failed");
				//outputJson.put("Error Msg",e.getLocalizedMessage());
				outputXML="<?xml version='1.0'?><Status>Failed</Status><Error>"+e.getLocalizedMessage()+"</Error>";
				getLog().severe(outputXML);
				
			}
			//return outputJson.toString();
			return outputXML;
	}

}
