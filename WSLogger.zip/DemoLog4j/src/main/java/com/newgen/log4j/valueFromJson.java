package com.newgen.log4j;

public class valueFromJson {
	private String input;
	
	public void setJson(String input) {
		this.input=input;
	}
	public String getJson() {
		return input;
	}
}
